package com.lomboktech.mangaapp.model;

public class ModelSlider {

    private String thumb;

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }
}